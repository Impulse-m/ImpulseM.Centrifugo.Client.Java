package io.github.centrifugal.centrifuge;

import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.X509TrustManager;
import java.net.Proxy;
import java.util.Map;

import okhttp3.OkHttpClient;

/**
 * Configuration for a {@link Client} instance.
 */
public class Options {
    public String getToken() {
        return token;
    }

    /**
     * Set connection token. If your tokens expire and you want SDK to automatically
     * refresh tokens then set ConnectionTokenGetter (see below).
     */
    public void setToken(String token) {
        this.token = token;
    }

    /**
     *  Connection token. This is a token you have to receive from your application backend.
     */
    private String token = "";

    public ConnectionTokenGetter getTokenGetter() {
        return tokenGetter;
    }

    /**
     * Set a method to extract new connection token upon expiration.
     */
    public void setTokenGetter(ConnectionTokenGetter tokenGetter) {
        this.tokenGetter = tokenGetter;
    }

    private ConnectionTokenGetter tokenGetter;

    private TokenExchange tokenExchange;

    public TokenExchange getTokenExchange() {
        return tokenExchange;
    }

    /**
     * Lets the client obtain and renew its connection token itself, over the connection, from a refresh token
     * the application persists. Exclusive with {@link #setTokenGetter}: a client created with both throws
     * IllegalArgumentException. Read when the client is created: set it before that, not after. Default null.
     */
    public void setTokenExchange(TokenExchange tokenExchange) {
        this.tokenExchange = tokenExchange;
    }

    public String getName() {
        return name;
    }

    /**
     * Set client name - name of this client. This should not be unique per client – it
     * identifies client application name actually, so name should have a limited
     * number of possible values. By default this client uses "java" as a name.
     */
    public void setName(String name) {
        this.name = name;
    }

    private String name = "java";

    public String getVersion() {
        return version;
    }

    /**
     * Set client version - version of application. This may be used for observability
     * on the server (for example in analytics).
     */
    public void setVersion(String version) {
        this.version = version;
    }

    private String version = "";

    public byte[] getData() {
        return data;
    }

    /**
     * Set custom connection data. This data will be delivered to server in Connect command.
     * For Centrifugo this may be useful in case of using connect proxy.
     */
    public void setData(byte[] data) {
        this.data = data;
    }

    private byte[] data;

    /**
     * Set custom headers for WebSocket Upgrade request.
     */
    public void setHeaders(Map<String, String> headers) {
        this.headers = headers;
    }

    public Map<String, String> getHeaders() {
        return headers;
    }

    private Map<String, String> headers;


    public int getTimeout() {
        return timeout;
    }

    /**
     * Set custom timeout for requests in milliseconds. By default, 5000 is used.
     */
    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }

    private int timeout = 5000;

    public String getInstance() {
        return instance;
    }

    /**
     * Set the connection instance: a random secret the application generates once per
     * installation or per tab and stores itself. It must match {@code [A-Za-z0-9_-]{22,64}}
     * (at least 128 bits). The server scopes exactly-once RPC records by it, so whoever knows
     * it can retransmit and cancel calls in its scope: never log or share it. Null clears it.
     * Read when the client is created: a later change does not reach that client.
     *
     * @throws IllegalArgumentException when the value does not match the pattern.
     */
    public void setInstance(String instance) {
        if (instance == null) {
            this.instance = "";
            return;
        }
        if (!Extensions.isValidInstance(instance)) {
            throw new IllegalArgumentException("instance must match [A-Za-z0-9_-]{22,64}");
        }
        this.instance = instance;
    }

    private String instance = "";

    public int getMaxPendingRpc() {
        return maxPendingRpc;
    }

    /**
     * Set how many rpc calls may be unsettled at once, for a client with an instance. A call counts
     * from its issue until it settles: a reply, an error, a timeout or a cancel. That includes a call which
     * waits for the connection, and a call kept for a resend. A call beyond the bound fails at once with
     * {@link ReplyError#LIMIT_EXCEEDED} and is not sent. A client without an instance has no bound: its calls wait
     * in memory while it is disconnected, so the memory held is about the call rate x the call timeout x the payload size.
     * Read when the client is created. Default 32.
     *
     * @throws IllegalArgumentException when the bound is less than 1.
     */
    public void setMaxPendingRpc(int maxPendingRpc) {
        if (maxPendingRpc < 1) {
            throw new IllegalArgumentException("maxPendingRpc must be at least 1");
        }
        this.maxPendingRpc = maxPendingRpc;
    }

    private int maxPendingRpc = 32;

    public int getMinReconnectDelay() {
        return minReconnectDelay;
    }

    /**
     * Set minimal time before reconnect attempt in milliseconds. By default, 500 is used.
     */
    public void setMinReconnectDelay(int minReconnectDelay) {
        this.minReconnectDelay = minReconnectDelay;
    }

    private int minReconnectDelay = 500;

    public int getMaxReconnectDelay() {
        return maxReconnectDelay;
    }

    /**
     * Set max time between reconnect attempts in milliseconds. By default, 20000 is used.
     */
    public void setMaxReconnectDelay(int maxReconnectDelay) {
        this.maxReconnectDelay = maxReconnectDelay;
    }

    private int maxReconnectDelay = 20000;

    public int getMaxServerPingDelay() {
        return maxServerPingDelay;
    }

    /**
     * Set the allowed silence from the server in milliseconds, counted from the last decoded message: a reply, a push
     * or a ping. By default, 10000 is used.
     */
    public void setMaxServerPingDelay(int maxServerPingDelay) {
        this.maxServerPingDelay = maxServerPingDelay;
    }

    private int maxServerPingDelay = 10000;

    public int getTokenRetryCap() {
        return tokenRetryCap;
    }

    /**
     * Set the longest delay in milliseconds before a failed timer token fetch or refresh is tried again. The delay
     * doubles with each failure in a row, up to this value; a success starts it again. By default, 300000 (5 minutes)
     * is used, so a getter which keeps failing is retried less and less often. A value at or below 20000 keeps the
     * flat retry of 10 to 20 seconds, as before. After a long token getter outage, the next timer retry can be up to
     * this cap away, so the connection may reconnect when its token expires instead of renewing.
     */
    public void setTokenRetryCap(int tokenRetryCap) {
        this.tokenRetryCap = tokenRetryCap;
    }

    private int tokenRetryCap = 300000;

    public OkHttpClient getOkHttpClient() {
        return this.okHttpClient;
    }

    /**
     * Set OkHttpClient. Can be used to pass configured custom OkHttpClient (with DNS, proxy, SSLSocketFactory etc.).
     */
    public void setOkHttpClient(OkHttpClient okHttpClient) {
        this.okHttpClient = okHttpClient;
    }

    private OkHttpClient okHttpClient;

    /**
     * Set proxy to use in default OkHttpClient builder. Won't be used if {@link #setOkHttpClient} was used.
     */
    public void setProxy(Proxy proxy) {
        this.proxy = proxy;
    }

    public Proxy getProxy() {
        return proxy;
    }

    private Proxy proxy;

    private String proxyLogin;
    private String proxyPassword;

    /**
     * Set proxy credentials for default OkHttpClient builder. Won't be used if {@link #setOkHttpClient} was used.
     */
    public void setProxyCredentials(String login, String password) {
        this.proxyLogin = login;
        this.proxyPassword = password;
    }

    public String getProxyLogin() {
        return proxyLogin;
    }

    public String getProxyPassword() {
        return proxyPassword;
    }

    public Dns getDns() {
        return this.dns;
    }

    /**
     * Set custom DNS resolver for default OkHttpClient builder. Won't be used if {@link #setOkHttpClient} was used.
     */
    public void setDns(Dns dns) {
        this.dns = dns;
    }

    private Dns dns;

    /**
     * Set custom SSLSocketFactory for default OkHttpClient builder. Won't be used if {@link #setOkHttpClient} was used.
     */
    public void setSSLSocketFactory(SSLSocketFactory sslSocketFactory) {
        this.sslSocketFactory = sslSocketFactory;
    }

    /**
     * Set custom SSLSocketFactory and X509TrustManager for default OkHttpClient builder. 
     * Won't be used if {@link #setOkHttpClient} was used.
     */
    public void setSSLSocketFactory(SSLSocketFactory sslSocketFactory, X509TrustManager trustManager) {
        this.sslSocketFactory = sslSocketFactory;
        this.trustManager = trustManager;
    }

    public SSLSocketFactory getSSLSocketFactory() {
        return this.sslSocketFactory;
    }

    private SSLSocketFactory sslSocketFactory;
    private X509TrustManager trustManager;

    public X509TrustManager getTrustManager() {
        return trustManager;
    }
}
